require 'pp'
require_relative 'composite_pattern'
require_relative 'mix_task'
require_relative 'add_dry_ingredients_task'

composite = CompositeTask.new('cake-example')
composite << MixTask.new

pp composite

puts composite[0].get_time_required
composite[1] = AddDryIngredientsTask.new

pp composite
