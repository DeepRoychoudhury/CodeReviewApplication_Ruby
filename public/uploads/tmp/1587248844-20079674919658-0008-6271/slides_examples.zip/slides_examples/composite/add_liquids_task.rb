require_relative 'task'
	
class AddLiquidsTask < Task

	def initialize
		super('Add Liquids')
	end

	def get_time_required
		4.0	
	end
end
