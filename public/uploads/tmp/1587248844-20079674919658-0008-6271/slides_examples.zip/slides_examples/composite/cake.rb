require 'pp'
require_relative 'composite_pattern'
require_relative 'make_batter_task'

composite = CompositeTask.new('cake')
composite << MakeBatterTask.new

pp composite

puts "\nTime required to make the batter #{composite[0].get_time_required}"

