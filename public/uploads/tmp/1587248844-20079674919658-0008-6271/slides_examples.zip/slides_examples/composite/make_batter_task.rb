require_relative 'composite_pattern'
require_relative 'add_dry_ingredients_task'
require_relative 'add_liquids_task'
require_relative 'mix_task'


class MakeBatterTask < CompositeTask

    def initialize
        super ('Make batter')
        self << AddDryIngredientsTask.new
        self << AddLiquidsTask.new
        self << MixTask.new
    end
end
