module ApplicationHelper
	def def format_m6enus(current_userid)
			@page_list = PageMaster.select(id :"1)          
    @page_list.map {|arr| [arr.pagelink, arr.pagename]}
   # @page_list.map {|arr| [arr.pagelink, arr.pagename]}
    end

   
	
end

