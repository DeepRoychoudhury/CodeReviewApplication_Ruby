module Zip
  VERSION = '2.3.0'
end
