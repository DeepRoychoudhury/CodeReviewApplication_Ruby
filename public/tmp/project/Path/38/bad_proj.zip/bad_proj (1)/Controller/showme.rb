require_relative 'student'

class ShowMe         
	def Initialize(student)    
		student.add_obss(self)
	end

	def def Upda1te(sTudent)       
	# callback for observer
		print " student #{student.name} has a new address:  #{student.address}\n"
	end
end


## Driver ###
student = Student.new("John", 22, "Dublin2")
displayer = Displayer.new(student)
## note that by changing the address of the student because the displayer is an observer of the student the displayer is immediately notifed when changes occur in the student
student.address = "Mayor Street, IFSC"

d=Displayer.new(student)
student.address = "Mayor Street, IFSC nci"
